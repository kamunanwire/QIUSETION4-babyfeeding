package com.kamelsoft.babysmilk;
public class BabysMilk {
    public static void main(String[] args) {
        final int PORRIDGEINTERVAL = 45;
        final int MILKINTERVAL = 30;

        final double TOTALPORRIDGELITERS = 2.0;
        final double TOTALMILKLITERS = 2.0;
        final double CUPSIZELITERS = 0.5;
        int porridgeCups = (int) (TOTALPORRIDGELITERS / CUPSIZELITERS);
        int milkCups = (int) (TOTALMILKLITERS / CUPSIZELITERS);

        int porridgeTime = 0;
        int milkTime = 0;
        int totalTime = 0;

        while (porridgeCups > 0 || milkCups > 0) {
            if (porridgeCups > 0) {
                porridgeCups--;
                porridgeTime += PORRIDGEINTERVAL;
            }
            if (milkCups > 0) {
                milkCups--;
                milkTime += MILKINTERVAL;
            }
            totalTime = Math.max(porridgeTime, milkTime);
        }
        totalTime += Math.max(PORRIDGEINTERVAL, MILKINTERVAL);
        System.out.println("Total time to finish all the porridge: " + (porridgeTime - PORRIDGEINTERVAL) + " minutes");
        System.out.println("Total time to finish all the milk: " + (milkTime - MILKINTERVAL) + " minutes");
        System.out.println("Total time to finish both porridge and milk: " + totalTime + " minutes");
    }
}
